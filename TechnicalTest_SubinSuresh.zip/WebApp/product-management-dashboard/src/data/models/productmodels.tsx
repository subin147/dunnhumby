export interface Product{
    Id:number,
    Name:string,
    Category:string,
    Code:string,
    Price:number,
    SKU:string,
    StockQuantity:number,
    DateAdded:string
}